# cotacaocalcruby
Programa que efetua cotação de preços de forma interativa e exporta o relatório automaticamente o relatório no formato HTML, podendo ser visualizado no navegador (Chrome, Firefox, etc.), e exportado via PDFno Web Browser. Também possui a funcionalidade de criação de arquivo (.csv) para fins estatísticos - Plataforma: WIndows (arquivo executável), Linux, Raspberry, MAC OS X

Como utilizar?

Windows:

1 - Extraia os arquivos "css.zip" e "img.zip" na mesma pasta onde está o arquivo "cotacao_calc.exe";
2 - Escolha um logotipo de sua preferência para ser utilizado no relatório, de preferência no formato (.png) e dimensão 200 X 201
e coloque-o dentro da pasta "img" que você extraiu (você pode substituir a imagem);
3 - Execute o arquivo "cotacao_calc.exe" e preencha os dados requeridos.
4 - Visualize os dados no arquivo "relatorio.html" - Abra-o em seu navegador e se quiser exporte-o para PDF.
5 - Visualize os dados em formato (.csv) no arquivo "data.csv" - Se você utilizou esse opção;

Outras plataformas:

1 - Instale a linguagem Ruby;
2 - Execute o comando "ruby cotacao_calc.rb"
(...)

Créditos: Eduardo Marques Braga de Faria


