puts "#################################### Cotação Calc ########################################"
puts "##########################################################################################"
puts "################# Desenvolvido por Eduardo Marques Braga de Faria ########################"
puts "################ Programação para Windows, Linux, Android e Raspberry ####################\n\n"


$item_number = 0
$item_desc = ""
$final_result = ""
$final_csv = ""
$total = 0
$abc_list = Array.new
$abc_list_size = 0
$abc_list_size_copy = 0

def save_csv()

File.open("dados_cotacao.csv", "w+") {|file| file.write $final_csv}
puts "Relatório salvo com sucesso no formato (.csv). Abra-o no software de planilha de sua preferência.[ENTER]\n"
ok = gets
exit

end

def welcome()
	print "Nome do órgão> "
	$orgao = gets.chop
	print "Número do processo> "
	$process = gets.chop
	print "Objeto da cotação> "
	object = gets.chop
	print "Setor Requisitante> "
	client = gets.chop

	$final_result.concat "	
<!doctype html>
<head>
	<title>Relatório de cotação</title>
	<meta charset = 'utf-8'>
	<link rel = 'stylesheet' href = 'css/styles.css'>
</head>
<body>
	<h1>Relatório de cotação</h1>
	<img src = 'img/imagem.png' alt = 'Imagem'>	
	<h2>#{$orgao}</h2>
	<br>
	<h3>Processo n° #{$process}<br>Objeto da Cotação: #{object}<br>Setor Requisitante: #{client}<br></h3>

	"

	$final_csv.concat "item,descricao,preco1,preco2,preco3,fonte1,fonte2,fonte3,quantidade,variancia,desvio_padrao,coeficiente_variacao,valor_unitario,valor_total,citerio\n"

end

def finish_job() 

	print "Data da pesquisa> "
	data = gets.chop
	print "Local> "
	local = gets.chop
	print "Nome do servidor responsável> "
	name_resp = gets.chop
	print "Cargo> "
	job = gets.chop

	$final_result.concat "

		<br>

		<h3>Total de itens pesquisados: #{$item_number}</h3>

		<br>

		<table id = 'res'>
			<tr>
				<th>Valor Global da Cotação</th>
				<td bgcolor = '#FFFF00'>R$ #{$total}</td>
			</tr>
		</table>

		<br>
		<br>
		<p>#{local}, #{data}</p>
		<br><br><br>
		<p>__________________________________________</p>
		<p>#{name_resp}</p>
		<p>#{job}</p>
		<br><br><br>
		
		<foot>Relatório gerado de forma automatizada pelo programa CotaçãoCalc</foot>
	</body>
	</html>

	"

	File.open("relatorio.html", "w") {|file| file.write $final_result}
	
	puts "O relatório está salvo no arquivo 'relatorio.html - Abra-o e visualize os resultados[ENTER].\n'"
	
	for i in $abc_list
	$abc_list_size = $abc_list_size + 1
	end

	$abc_list_size_copy = $abc_list_size
	abc_list_sorted = $abc_list.sort
	
	abc_list_sorted_rev = Array.new($abc_list_size)

	for i in abc_list_sorted
	$abc_list_size_copy = $abc_list_size_copy - 1
	abc_list_sorted_rev[$abc_list_size_copy] = i
	end

	puts "Deseja também gerar o relatório em formato (.csv) para fins estatísticos?"	
	puts "1. Sim"
	puts "2. Não"
	puts "\n"
	print "Resposta> "
	resp = gets.chop
	
	case resp.to_i
	
	when 1
		save_csv
	
	when 2
		
		puts "Pressione [ENTER] para sair do programa."
		ok = gets
		exit
	end

	puts "Valores em ordem decrescente:"
	puts "#{abc_list_sorted_rev}"
	

end

welcome

def exit_program() 
	exit
end

def new_item() 
	count = 0
	list_values = Array.new(3)


	$item_number = $item_number + 1
	puts "Item n° #{$item_number}"
	print "Descrição do objeto> "
	$item_desc = gets.chop
	
	print "Preço 1> "

	price_one = gets.chop.to_f
	puts "Selecione a fonte:\n\n"
	puts "1. Painel de Preços"
	puts "2. Outros Entes Públicos"
	puts "3. Mídia Especializada / Domínio Amplo"
	puts "4. Fornecedor"
	print "Fonte > "
	font_one = gets.chop
	case font_one.to_i
	
	when 1
		font_one = "Painel de Preços"

	when 2
		font_one = "Outros Entes Públicos"
	when 3
		font_one = "Mídia Especializada / Domínio Amplo"

	when 4
		font_one = "Fornecedor"
	else
		font_one = "Não Informada"
		
	end
	
	puts "\n"
	print "Preço 2> "

	price_two = gets.chop.to_f
	puts "Selecione a fonte:\n\n"
	puts "1. Painel de Preços"
	puts "2. Outros Entes Públicos"
	puts "3. Mídia Especializada / Domínio Amplo"
	puts "4. Fornecedor"
	print "Fonte > "
	font_two = gets.chop
	case font_two.to_i
	
	when 1
		font_two = "Painel de Preços"

	when 2
		font_two = "Outros Entes Públicos"
	when 3
		font_two = "Mídia Especializada / Domínio Amplo"

	when 4
		font_two = "Fornecedor"
	else
		font_two = "Não Informada"
		
	end

	puts "\n"
	print "Preço 3> "

	price_three = gets.chop.to_f
	puts "Selecione a fonte:\n\n"
	puts "1. Painel de Preços"
	puts "2. Outros Entes Públicos"
	puts "3. Mídia Especializada / Domínio Amplo"
	puts "4. Fornecedor"
	print "Fonte > "
	font_three = gets.chop
	case font_three.to_i
	
	when 1
		font_three = "Painel de Preços"

	when 2
		font_three = "Outros Entes Públicos"
	when 3
		font_three = "Mídia Especializada / Domínio Amplo"

	when 4
		font_three = "Fornecedor"
	else
		font_three = "Não Informada"
		
	end
		
	puts "\n"

	list_values[0] = price_one
	list_values[1] = price_two
	list_values[2] = price_three

	puts "Ótimo! Já temos 3 (três) preços coletados. Escolha a metodologia de cálculo:"

	pre_mean = (list_values.inject(:+).to_f / list_values.size).to_f
	var = ((((price_one - pre_mean) ** 2) + ((price_two - pre_mean) ** 2) + ((price_three - pre_mean) ** 2)) / 2).to_f
	std_dv = Math.sqrt(var).to_f
	cv = ((std_dv / pre_mean) * 100).to_f
	puts "\nO coeficiente de variação é #{cv}%. Para valores maiores do que 25%, recomenda-se a mediana ou o menor valor.\n"

	puts ""
	puts "1. Média"
	puts "2. Mediana"
	puts "3. Menor valor"

	print "Metodologia de cálculo> "
	calc_answer = gets.chop

	case calc_answer.to_i

	when 1
		mean = (list_values.inject(:+).to_f / list_values.size).to_f
		puts "A média é #{mean}"
		print "Informe a quantidade do item:> "
		so_much = gets.chop.to_i
		mult = (mean * so_much).to_f
		pone_calc = (price_one * so_much).to_f
		ptwo_calc = (price_two * so_much).to_f
		pthree_calc = (price_three * so_much).to_f
		puts ">>>>> O valor global do item é #{mult} <<<<<"
		$abc_list << mult
		

		$total = $total + mult

		$final_csv.concat "#{$item_number},#{$item_desc},#{price_one},#{price_two},#{price_three},#{font_one},#{font_two},#{font_three},#{so_much},#{var},#{std_dv},#{cv},#{mean},#{mult},Media\n"
		$final_result.concat "

		<p><strong>Item #{$item_number}</strong><br><strong>Descrição: </strong>#{$item_desc}</p>
		<br>
		
		<br>
		
		<table>
		<tr>
			<th></th>
			<th>Valor Unitário</th>
			<th>Quantidade</th>
			<th>Fonte de Preço</th>
			<th>Total</th>
		</tr>

		<tr>
			<th>Preço 1</th>
			<td>R$ #{price_one}</td>
			<td>#{so_much}</td>
			<td>#{font_one}</td>
			<td>R$ #{pone_calc}</td>

		</tr>

		<tr>
			<th>Preço 2</th>
			<td>R$ #{price_two}</td>
			<td>#{so_much}</td>
			<td>#{font_two}</td>
			<td>R$ #{ptwo_calc}</td>

		</tr>

		<tr>
			<th>Preço 3</th>
			<td>R$ #{price_three}</td>
			<td>#{so_much}</td>
			<td>#{font_three}</td>
			<td>R$ #{pthree_calc}</td>

		</tr>

		<tr>
			<th>Variância</th>
			<td>#{var}</td>

		</tr>

		<tr>
			<th>Desvio-Padrão</th>
			<td>#{std_dv}</td>
		</tr>

		<tr>
			<th>Coeficiente de Variação</th>
			<td>#{cv} %</td>
		</tr>


		<tr>
			<th>Valor de Mercado (Unitário)</th>
			<td>R$ #{mean}</td>
			<th>Critério Utilizado</th>
			<td>Média</td>
		</tr>
	
		<tr>
			<th>Valor de Mercado (Total)</th>
			<td bgcolor = '#FFFF00'>R$ #{mult}</td>
		</tr>
		</table>
		<br>

		<br>
		
		
		"


	when 2

		list_len = list_values.size
		rank_list = list_values.sort
		med = rank_list[1].to_f
		puts ">>>>> A mediana é #{med} <<<<<"
		print "Informe a quantidade do item:> "
		much_med = gets.chop.to_i
		mult_med = (med * much_med).to_f
		pone_calc = (price_one * much_med).to_f
		ptwo_calc = (price_two * much_med).to_f
		pthree_calc = (price_three * much_med).to_f
		puts ">>>>> O valor global do item é #{mult_med} <<<<<"

		$total = $total + mult_med

		$final_csv.concat "#{$item_number},#{$item_desc},#{price_one},#{price_two},#{price_three},#{font_one},#{font_two},#{font_three},#{much_med},#{var},#{std_dv},#{cv},#{med},#{mult_med},Mediana\n"
		$final_result.concat "

		<p><strong>Item #{$item_number}</strong><br><strong>Descrição: </strong>#{$item_desc}</p>
		<br>
		
		<br>
		
		<table>
		<tr>
			<th></th>
			<th>Valor Unitário</th>
			<th>Quantidade</th>
			<th>Fonte de Preço</th>
			<th>Total</th>
		</tr>

		<tr>
			<th>Preço 1</th>
			<td>R$ #{price_one}</td>
			<td>#{much_med}</td>
			<td>#{font_one}</td>
			<td>R$ #{pone_calc}</td>

		</tr>

		<tr>
			<th>Preço 2</th>
			<td>R$ #{price_two}</td>
			<td>#{much_med}</td>
			<td>#{font_two}</td>
			<td>R$ #{ptwo_calc}</td>

		</tr>

		<tr>
			<th>Preço 3</th>
			<td>R$ #{price_three}</td>
			<td>#{much_med}</td>
			<td>#{font_three}</td>
			<td>R$ #{pthree_calc}</td>

		</tr>

		<tr>
			<th>Variância</th>
			<td>#{var}</td>

		</tr>

		<tr>
			<th>Desvio-Padrão</th>
			<td>#{std_dv}</td>
		</tr>

		<tr>
			<th>Coeficiente de Variação</th>
			<td>#{cv} %</td>
		</tr>


		<tr>
			<th>Valor de Mercado (Unitário)</th>
			<td>R$ #{med}</td>
			<th>Critério Utilizado</th>
			<td>Mediana</td>
		</tr>
	
		<tr>
			<th>Valor de Mercado (Total)</th>
			<td bgcolor = '#FFFF00'>R$ #{mult_med}</td>
		</tr>
		</table>
		<br>

		<br>
		
		
		"

	

	when 3
		
		list_len_min = list_values.size
		rank_list_min = list_values.sort
		min = rank_list_min[0].to_f
		puts ">>>>> O menor valor é #{min} <<<<<"
		print "Informe a quantidade do item:> "
		much_min = gets.chop.to_i
		pone_calc = (price_one * much_min).to_f
		ptwo_calc = (price_two * much_min).to_f
		pthree_calc = (price_three * much_min).to_f
		mult_min = (min * much_min).to_f
		puts ">>>>> O valor global do item é #{mult_min} <<<<<"

		$total = $total + mult_min

		$final_csv.concat "#{$item_number},#{$item_desc},#{price_one},#{price_two},#{price_three},#{font_one},#{font_two},#{font_three},#{much_min},#{var},#{std_dv},#{cv},#{min},#{mult_min},Media\n"
		$final_result.concat "

		<p><strong>Item #{$item_number}</strong><br><strong>Descrição: </strong>#{$item_desc}</p>
		<br>
		
		<br>
		
		<table>
		<tr>
			<th></th>
			<th>Valor Unitário</th>
			<th>Quantidade</th>
			<th>Fonte de Preço</th>
			<th>Total</th>
		</tr>

		<tr>
			<th>Preço 1</th>
			<td>R$ #{price_one}</td>
			<td>#{much_min}</td>
			<td>#{font_one}</td>
			<td>R$ #{pone_calc}</td>

		</tr>

		<tr>
			<th>Preço 2</th>
			<td>R$ #{price_two}</td>
			<td>#{much_min}</td>
			<td>#{font_two}</td>
			<td>R$ #{ptwo_calc}</td>

		</tr>

		<tr>
			<th>Preço 3</th>
			<td>R$ #{price_three}</td>
			<td>#{much_min}</td>
			<td>#{font_three}</td>
			<td>R$ #{pthree_calc}</td>

		</tr>

		<tr>
			<th>Variância</th>
			<td>#{var}</td>

		</tr>

		<tr>
			<th>Desvio-Padrão</th>
			<td>#{std_dv}</td>
		</tr>

		<tr>
			<th>Coeficiente de Variação</th>
			<td>#{cv} %</td>
		</tr>


		<tr>
			<th>Valor de Mercado (Unitário)</th>
			<td>R$ #{min}</td>
			<th>Critério Utilizado</th>
			<td>Menor Valor</td>
		</tr>
	
		<tr>
			<th>Valor de Mercado (Total)</th>
			<td bgcolor = '#FFFF00'>R$ #{mult_min}</td>
		</tr>
		</table>
		<br>

		<br>
		
		
		"

	end	

end

def main()

	puts "Escolha uma opção:"
	puts ""
	puts "1. Novo Item"
	puts "2. Encerrar cotação"
	puts "3. Sair"
	puts ""

	print "Opção> "
	answer = gets.chop

	case answer.to_i 

		when 1
			new_item
			

		when 2 

			finish_job
		

		when 3 
			exit_program
		

	end

end

while true 

main

end





